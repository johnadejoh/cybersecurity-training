AUTOPSY BEGINNER LAB - INSTRUCTOR NOTES

Scenario: A USB folder was provided to the help desk for a basic examination after a
fictional report that a project draft could not be located. Students should examine the
provided files, search for key terms, identify relevant items, and document what they found.

Recommended: extract the ZIP to a local folder before adding it in Autopsy. Keep the case
folder separate from the evidence_usb folder. Use this only as a logical-files exercise.
