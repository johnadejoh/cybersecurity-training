AUTOPSY BEGINNER LAB - SAMPLE EVIDENCE

All files in this folder are fictional training materials. They contain no real personal
information, no malware, and no genuine system or browser records.

Use this folder as a Logical Files data source in Autopsy. This sample is designed for:
- browsing files and folders;
- viewing file metadata and content;
- identifying file types;
- keyword searching for Project Falcon and CONFIDENTIAL;
- tagging relevant items and preparing a short report.

Important limitation: because this is a folder of ordinary files, it does not contain
unallocated disk space or deleted-file remnants. It is not suitable for demonstrating
recovery of deleted files.
